﻿using UnityEngine;
using System.Collections;

public class csDeadr_Piece : MonoBehaviour
{
    // 이동 가능한 지점을 표시할 게임 오브젝트
    public GameObject point;
    // 특정 이벤트 발생 시 사용될 게임 오브젝트
    public GameObject use;
    // 오디오 소스 컴포넌트
    public AudioSource _audio;

    // 현재 오브젝트의 임시 위치 저장 변수
    int tempA = 10, tempB = 10;
    // 오브젝트가 이동할 목적지 위치 저장 변수
    int destA = 0, destB = 0;

    public void Start()
    {
        // 게임 시작 시 오디오 소스 인스턴스화
        _audio = Instantiate(_audio);
    }

    void Update()
    {
        // 플레이어가 아닌 상대방의 이동 시도와 실제 이동 위치가 설정되었는지 확인
        if (csMain.move && !csMain.player && (csMain.realmove == GameObject.Find("(" + tempA + "," + tempB + ")").transform.position))
        {
            // 목적지 위치 설정
            destA = csPoint.moveA;
            destB = csPoint.moveB;

            // 오디오 재생
            _audio.Play();

            // `use` 오브젝트를 목적지 위치에 인스턴스화하고, 180도 회전시킵니다.
            Instantiate(use,
                GameObject.Find("(" + destA + "," + destB + ")").transform.position,
                Quaternion.Euler(0, 0, 180));

            // 현재 오브젝트 파괴
            Destroy(gameObject);

            // 목적지 위치에 상대방의 표시를 함
            csMain.r_coordinates[destA, destB] = true;
            // 플레이어의 차례로 변경
            csMain.player = true;
            // 이동 완료 상태로 설정
            csMain.move = false;
            // 실제 이동 위치 초기화
            csMain.realmove = Vector3.zero;
            // 임시 위치 변수 초기화
            tempA = 10;
            tempB = 10;
        }
    }

    void OnMouseDown()
    {
        // 현재 상대방의 차례일 때
        if (!csMain.player)
        {
            // 클릭된 오브젝트 위치를 실제 이동 위치로 설정
            csMain.realmove = transform.position;

            // 이전에 생성된 모든 "clone" 태그가 있는 오브젝트를 찾아 파괴
            var clones = GameObject.FindGameObjectsWithTag("clone");
            foreach (var clone in clones)
                Destroy(clone);

            // 클릭된 게임 오브젝트의 위치를 검색하여 tempA와 tempB에 저장
            for (int i = 1; i < 4; i++)
            {
                if (transform.position == GameObject.Find("(" + i + ",-1)").transform.position)
                {
                    tempA = i;
                    tempB = -1;
                }

            }

            // 이동 가능한 좌표를 시각적으로 표시
            for (int i = 1; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                    if (!csMain.g_coordinates[i, j] && !csMain.r_coordinates[i, j])
                    {
                        Instantiate(point,
                           GameObject.Find("(" + i + "," + j + ")").transform.position + Vector3.forward * 0.26f,
                           GameObject.Find("(" + i + "," + j + ")").transform.rotation);
                    }
            }
        }
    }
}
