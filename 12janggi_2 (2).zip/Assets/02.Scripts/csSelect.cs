﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class csSelect : MonoBehaviour
{
	public void playbutton()
    {
        SceneManager.LoadScene("01.PlayScenes", LoadSceneMode.Single);
        csMain.player = true;   //초록팀부터 시작
    }





    public void Exit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
