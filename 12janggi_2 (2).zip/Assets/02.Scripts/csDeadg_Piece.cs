﻿using UnityEngine;
using System.Collections;

public class csDeadg_Piece : MonoBehaviour
{
    // 이동 가능한 지점을 표시할 프리팹
    public GameObject point;
    // 특정 동작을 실행할 때 사용될 게임 오브젝트
    public GameObject use;
    // 오디오 소스 컴포넌트
    public AudioSource _audio;

    // 현재 오브젝트의 위치를 저장하는 임시 변수
    int tempA = 10, tempB = 10;
    // 오브젝트가 이동할 목적지의 위치를 저장하는 변수
    int destA = 0, destB = 0;

    public void Start()
    {
        // 게임 시작 시 오디오 소스를 인스턴스화합니다.
        _audio = Instantiate(_audio);
    }

    void Update()
    {
        // 플레이어가 이동을 시도하고, 현재 플레이어의 차례이며, 실제 이동 위치가 설정된 경우
        if (csMain.move && csMain.player && (csMain.realmove == GameObject.Find("(" + tempA + "," + tempB + ")").transform.position))
        {
            // 목적지 위치 설정
            destA = csPoint.moveA;
            destB = csPoint.moveB;

            // 오디오 재생
            _audio.Play();

            // `use` 오브젝트를 목적지 위치에 인스턴스화합니다.
            Instantiate(use,
                GameObject.Find("(" + destA + "," + destB + ")").transform.position,
                Quaternion.Euler(0, 0, 0));

            // 현재 오브젝트를 파괴합니다.
            Destroy(gameObject);

            // 목적지 위치를 차지하고 있음을 표시하고, 플레이어의 차례를 변경합니다.
            csMain.g_coordinates[destA, destB] = true;
            csMain.player = false;
            csMain.move = false;
            csMain.realmove = Vector3.zero;
            // 임시 위치 변수 초기화
            tempA = 10;
            tempB = 10;
        }
    }

    void OnMouseDown()
    {
        // 현재 플레이어의 차례인 경우
        if (csMain.player)
        {
            // 클릭된 오브젝트의 위치를 실제 이동 위치로 설정합니다.
            csMain.realmove = transform.position;

            // "clone" 태그가 있는 모든 오브젝트를 찾아 파괴합니다.
            var clones = GameObject.FindGameObjectsWithTag("clone");
            foreach (var clone in clones)
                Destroy(clone);

            // 클릭된 게임 오브젝트의 위치를 검색하여 tempA와 tempB에 저장합니다.
            for (int i = 0; i < 3; i++)
            {
                if (transform.position == GameObject.Find("(" + i + ",3)").transform.position)
                {
                    tempA = i;
                    tempB = 3;
                }
            }

            // 움직일 수 있는 좌표를 표시합니다.
            // 게임 보드 위의 모든 위치를 검사하여, 갈 수 있는 위치에 `point` 프리팹을 인스턴스화합니다.
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    if (!csMain.g_coordinates[i, j] && !csMain.r_coordinates[i, j])
                    {
                        Instantiate(point,
                           GameObject.Find("(" + i + "," + j + ")").transform.position + Vector3.forward * 0.26f,
                           GameObject.Find("(" + i + "," + j + ")").transform.rotation);
                    }
            }
        }
    }
}
