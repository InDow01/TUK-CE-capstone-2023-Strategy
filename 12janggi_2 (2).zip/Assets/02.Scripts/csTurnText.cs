﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class csTurnText : MonoBehaviour
{
    Text text;

    void Start()
    {
        text = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if (csMain.player)
        {
            text.text = "Player1";
            text.color = Color.green; // Player1의 텍스트 색상을 초록색으로 설정
        }
        else
        {
            text.text = "Player2";
            text.color = Color.red; // Player2의 텍스트 색상을 빨간색으로 설정
        }
    }
}
