﻿using UnityEngine;
using System.Collections;

public class csMoveg_Ja : MonoBehaviour
{
    // 이동 가능한 지점과 공격 가능한 지점을 표시할 프리팹
    public GameObject point;
    public GameObject pointkill;
    // 적을 제거했을 때 생성될 오브젝트
    public GameObject dead;
    // 상대 진영에 도달했을 때 변환될 새로운 오브젝트
    public GameObject g_hu;
    // 이동이나 행동 시 재생될 오디오 클립
    public AudioSource _audio;

    // 목표 위치를 저장할 Transform 변수
    Transform obj;

    // 오브젝트 이동 속도
    float speed = 0.0f;
    // 현재 오브젝트의 임시 위치
    int tempA = 10, tempB = 10;
    // 오브젝트가 이동할 목표 위치
    int destA = 0, destB = 0;

    public void Start()
    {
        // 게임 시작 시 오디오 소스를 인스턴스화하여 준비
        _audio = Instantiate(_audio);
    }

    void Update()
    {
        // 플레이어가 이동할 차례이고, 실제 이동할 위치가 정해진 경우
        if (csMain.move && csMain.player && (csMain.realmove == GameObject.Find("(" + tempA + "," + tempB + ")").transform.position))
        {
            // 상대방을 죽일 경우와 아닐 경우를 구분하여 목표 좌표를 저장
            if (csMain.eat)
            {
                destA = csPointKill.moveA;
                destB = csPointKill.moveB;
            }
            else
            {
                destA = csPoint.moveA;
                destB = csPoint.moveB;
            }

            // 이동 중 다른 오브젝트와의 충돌을 방지하기 위해 BoxCollider를 트리거로 설정
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            // 목표 위치로의 Transform 컴포넌트를 찾아 저장
            obj = GameObject.Find("(" + destA + "," + destB + ")").transform;
            // 이동 속도를 점진적으로 증가시키며 목표 위치로 이동
            speed += Time.deltaTime * 5.0f;
            transform.position = Vector3.Lerp(transform.position, obj.position, speed);

            // 목표 위치에 도달했을 경우의 처리
            if (transform.position == obj.position)
            {
                _audio.Play(); // 도착 시 오디오 재생

                // 상대 진영에 도달한 경우, 지정된 오브젝트로 변환
                if (destA == 3)
                {
                    Instantiate(g_hu, GameObject.Find("(" + destA + "," + destB + ")").transform.position, Quaternion.Euler(0, 0, 0));
                    Destroy(gameObject); // 원래 오브젝트 제거
                }

                // 좌표 정보 업데이트 및 게임 상태 변경
                csMain.g_coordinates[tempA, tempB] = false;
                csMain.g_coordinates[destA, destB] = true;
                csMain.player = false;
                csMain.move = false;
                csMain.realmove = Vector3.zero;
                gameObject.GetComponent<BoxCollider>().isTrigger = false; // Collider를 다시 일반 상태로 복원
                speed = 0.0f; // 이동 속도 초기화
                tempA = 10; // 임시 위치 초기화
                tempB = 10;
            }
        }
    }

    void OnMouseDown()
    {
        // 플레이어의 차례일 때 마우스로 오브젝트를 클릭한 경우
        if (csMain.player)
        {
            csMain.realmove = transform.position; // 실제 이동할 위치로 현재 위치 설정

            // 이전에 생성된 이동 가능한 포인트를 모두 제거
            var clones = GameObject.FindGameObjectsWithTag("clone");
            foreach (var clone in clones)
                Destroy(clone);

            // 현재 오브젝트의 위치를 기반으로 이동 가능한 위치를 검색 및 저장
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                    if (transform.position == GameObject.Find("(" + i + "," + j + ")").transform.position)
                    {
                        tempA = i;
                        tempB = j;
                    }
            }

            // 이동 가능한 위치를 시각적으로 표시
            // 전방 이동 가능한 경우에 한해 이동 및 공격 가능 위치를 표시
            if (tempA + 1 < 4 && !csMain.g_coordinates[tempA + 1, tempB])
            {
                if (!csMain.r_coordinates[tempA + 1, tempB])
                    Instantiate(point, GameObject.Find("(" + (tempA + 1) + "," + tempB + ")").transform.position + Vector3.forward * 0.26f, GameObject.Find("(" + (tempA + 1) + "," + tempB + ")").transform.rotation);
                else
                    Instantiate(pointkill, GameObject.Find("(" + (tempA + 1) + "," + tempB + ")").transform.position - Vector3.forward * 0.26f, GameObject.Find("(" + (tempA + 1) + "," + tempB + ")").transform.rotation);
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        // 오브젝트가 다른 오브젝트와 충돌했을 때, isTrigger가 false인 경우만 처리
        if (!gameObject.GetComponent<BoxCollider>().isTrigger)
        {
            int x, y;
            // 상대방을 죽일 경우와 그렇지 않은 경우의 목표 좌표 저장
            if (csMain.eat)
            {
                x = csPointKill.moveA;
                y = csPointKill.moveB;
            }
            else
            {
                x = csPoint.moveA;
                y = csPoint.moveB;
            }

            // 충돌한 위치가 목표 위치와 동일하고 상대방 오브젝트를 공격하는 경우
            if (transform.position == GameObject.Find("(" + x + "," + y + ")").transform.position)
            {
                csMain.g_coordinates[x, y] = false; // 해당 위치의 좌표 업데이트

                Destroy(gameObject); // 현재 오브젝트 제거

                // 죽은 오브젝트를 표시할 위치에 dead 오브젝트 인스턴스화
                Instantiate(dead, GameObject.Find("(" + (3 - csMain.deadg_Piece) + ",-1)").transform.position, Quaternion.Euler(0, 0, 180));

                // 죽은 오브젝트 수 업데이트
                csMain.deadg_Piece++;
                if (csMain.deadg_Piece == 3) // 죽은 오브젝트의 수가 특정 값에 도달하면 초기화
                    csMain.deadg_Piece = 0;
            }
        }
    }
}
